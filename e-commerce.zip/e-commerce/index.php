<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {
    header('Location: admin_login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        .main{
    width: 40%;
    box-shadow: 1px 1px 10px silver;
    margin-top: 45px;
    padding: 10px;

        }
            
        h2{
            font-family: "Slabo 27px", serif;
        }
        input{
            margin-bottom: 10px;
            width: 50%;
            padding: 5px;
            font-family: "Slabo 27px", serif;
            font-size: 15px;
            font-weight: bold;

        }

        button{
            border:none;
            padding: 10px;
            width: 30%;
            font-weight: 15px;
            background-color: lightblue;
            cursor: pointer;
            font-family: "Slabo 27px", serif;
            margin-bottom: 15px;

        }

        label{
            padding: 10px;
            cursor: pointer;
            font-weight: bold;
            font-size: 18px;
            background-color: lightpink;
            font-family: "Slabo 27px", serif;
            
        }

        a{

            text-decoration: none;
            font-size: 20px;
         

        }
        nav {
                    background-color: #333;
            color: #fff;
            padding: 10px 20px;
        }
        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: space-between;
        }
        nav ul li {
            display: inline;
            padding: 0 10px;
        }
        nav ul li a {
            color: #fff;
            text-decoration: none;
        }
        nav ul li a:hover {
            text-decoration: underline;
        }

        nav ul{


            font-size:30px;
        }


    </style>
</head>
<body>
    
    <nav>
        <ul>
           
            
            <li>Current admin :<?php echo $_SESSION['username']; ?></li>
            <li><a href="orders.php">Orders</a></li>
            <li><a href="shop.php">Go to store page</a></li>
            <li><a href="products.php">All products</a></li>
            <li><a href="admin_login.php">Loge out</a></li>


            
        </ul>
    </nav>


    <center>
      

        <div class="main">
        
            <form method="post" action="insert.php" enctype="multipart/form-data">
                <h3>Admin control panel</h3>
                <img src="logo.png" alt="logo" width="450px">
                <br><br>

                <h3>Add New Product</h3>
                
                <label for="name">pruduct name:</label>
                <input type="text"  name="name" required><br><br>
              
                <label for="price">product price :</label>
                <input type="text"  name="price" required><br><br>

                <label for="category">Category:</label>
                <select id="category" name="category" required>
                <option value="novels">Novels</option>
                <option value="children Stories">Children's Stories</option>
                </select><br><br>
                
                <label for="file">uplad product image </label><br>
                <input type="file" id="file" name="image" style='display:none' required><br><br>
                <button type="submit" name="upload">uplad product</button>
                <br><br>
                
            </form>


            </form>
        </div>
        <p>Developed by Meaad Farag, Software Engineer</p>

    </center>

</body>
</html>