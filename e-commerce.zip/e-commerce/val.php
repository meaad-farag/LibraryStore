<?php
include('config.php');
$ID= $_GET['id'];
$up=mysqli_query($conn, "select * from products where id=$ID");
$data = mysqli_fetch_array($up);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirm purchase</title>
    <style>
        input{
            display: none;
        }

        .main{
            width: 30%;
            padding: 20px;
            box-shadow: 1px 1px 10px silver;
            margin-top: 50px;
        }
    </style>


    
    <link rel="stylesheet" href="index.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Slabo+27px&display=swap" rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

</head>
<body>
    <center>
        <div class="main">
            <form action="insert_card.php" method="post">
                <h4>Do you want to complete the purchase</h4><br>

                <input type="text" name= "id" value='<?php echo $data['id']?>'><br>

                <input type="text" name= "name" value='<?php echo $data['name']?>'><br>

                <input type="text" name= "price" value='<?php echo $data['price']?>'><br>

                <button name="add" type="submit" class="btn-warning">Confirm add to cart</button><br>

                <a href="shop.php">Back to Products Page</a>
            </form>
        </div>
    </center>
</body>

</html>