

<?php

include 'config.php';
session_start();
$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
};

if(isset($_GET['logout'])){
   unset($user_id);
   session_destroy();
   header('location:shop.php');
};

if(isset($_POST['add_to_cart'])){

   $product_name = $_POST['product_name'];
   $product_price = $_POST['product_price'];
   $product_image = $_POST['product_image'];
   $product_quantity = $_POST['product_quantity'];

   $select_cart = mysqli_query($conn, "SELECT * FROM `user_cart` WHERE name = '$product_name' AND user_id = '$user_id'") or die('query failed');

   if(mysqli_num_rows($select_cart) > 0){
      $message[] = 'product is already in the cart';
   }else{
      mysqli_query($conn, "INSERT INTO `user_cart`(user_id, name, price, image, quantity) VALUES('$user_id', '$product_name', '$product_price', '$product_image', '$product_quantity')") or die('query failed');
      $message[] = 'product added to the cart ✔';
   }

};

if(isset($_POST['update_cart'])){
   $update_quantity = $_POST['cart_quantity'];
   $update_id = $_POST['cart_id'];
   mysqli_query($conn, "UPDATE `user_cart` SET quantity = '$update_quantity' WHERE id = '$update_id'") or die('query failed');
   $message[] = 'shopping cart quantity updated successfully!';
}

if(isset($_GET['remove'])){
   $remove_id = $_GET['remove'];
   mysqli_query($conn, "DELETE FROM `user_cart` WHERE id = '$remove_id'") or die('query failed');
   header('location:user_cart.php');
}
  
if(isset($_GET['delete_all'])){
   mysqli_query($conn, "DELETE FROM `user_cart` WHERE user_id = '$user_id'") or die('query failed');
   header('location:user_cart.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>shopping cart</title>

   
     
       
   <style>

        h1{
            font-family: "Slabo 27px", serif;
            font-weight: bold;}
        body {
         font-family: 'Slabo 27px', serif;
         background-color: #f8f9fa;
         margin: 0;
         padding: 0;
        }

        .navbar {
            background-color: #343a40;
            color: white;
            padding: 15px;
            text-align: center;
        }

        .navbar a {
            color: white;
            font-size: 25px;
            margin: 0 15px;
            text-decoration: none;
        }

        .navbar p, .navbar span {
            color: white;
            font-size: 25px;
            margin: 0;
        }

        .container {
            width: 90%;
            margin: 0 auto;
            padding: 20px;
        }

        .user-profile {
            background-color: white;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }

        .heading {
            text-align: center;
            font-size: 2em;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table, th, td {
            border: 1px solid #dee2e6;
        }

        th, td {
            padding: 15px;
            text-align: center;
        }

        th {
            background-color: #f8f9fa;
        }

        .delete-btn {
            background-color: #dc3545;
            color: white;
            padding: 10px;
            border: none;
            cursor: pointer;
            text-decoration: none;
        }

        .delete-btn.disabled {
            background-color: #6c757d;
            cursor: not-allowed;
        }

        .option-btn {
            background-color: #28a745;
            color: white;
            padding: 10px;
            border: none;
            cursor: pointer;
        }

        .message {
            background-color: #ffc107;
            color: #212529;
            padding: 10px;
            margin-bottom: 20px;
            text-align: center;
            cursor: pointer;
        }
   </style>


    <link rel="stylesheet" href="index.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Slabo+27px&display=swap" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

</head>
<body>
   
<?php
if(isset($message)){
   foreach($message as $message){
      echo '<div class="message" onclick="this.remove();">'.$message.'</div>';
   }
}
?>

<div class="container">

<div class="user-profile">

   <?php
      $select_user = mysqli_query($conn, "SELECT * FROM `users` WHERE id = '$user_id'") or die('query failed');
      if(mysqli_num_rows($select_user) > 0){
         $fetch_user = mysqli_fetch_assoc($select_user);
      };
   ?>

   <nav class="navbar navbar-dark bg-dark">
        <a id=a class="navbar-brand" href= "session_shop.php"> Back to shopping</a>
        <p>Current User : <span><?php echo $fetch_user['name']; ?></span> </p>
        <a href="session_shop.php?logout=<?php echo $user_id; ?>" onclick="return confirm(' Are you sure you want to log out ?');" class="delete-btn">Log out </a>
    </nav>

    <center>
        

        
<div class="shopping-cart">

<h1 class="heading"> shopping cart</h1><br>

<table>
   <thead>
      <th>image</th>
      <th>name</th>
      <th>price</th>
      <th>total amount</th>
      <th> total price</th>
      <th>delete items</th>
   </thead>
   <tbody>
   <?php
      $cart_query = mysqli_query($conn, "SELECT * FROM `user_cart` WHERE user_id = '$user_id'") or die('query failed');
      $grand_total = 0;
      if(mysqli_num_rows($cart_query) > 0){
         while($fetch_cart = mysqli_fetch_assoc($cart_query)){
   ?>
      <tr>
         <td><img src=<?php echo $fetch_cart['image']; ?> height="75" alt=""></td>
         <td><?php echo $fetch_cart['name']; ?></td>
         <td><?php echo $fetch_cart['price']; ?>$ </td>
         <td>
            <form action="" method="post">
               <input type="hidden" name="cart_id" value="<?php echo $fetch_cart['id']; ?>">
               <input type="number" min="1" name="cart_quantity" value="<?php echo $fetch_cart['quantity']; ?>">
               <input type="submit" name="update_cart" value="Edit" class="option-btn">
            </form>
         </td>
         <td><?php echo $sub_total = (str_replace('$', '', $fetch_cart['price']) * $fetch_cart['quantity']); ?>$</td>
         <td><a href="user_cart.php?remove=<?php echo $fetch_cart['id']; ?>" class="delete-btn" onclick="return confirm('delete item from cart?');">Delete</a></td>
      </tr>
   <?php
      $grand_total += $sub_total;
         }
      }else{
         echo '<tr><td style="padding:20px; text-transform:capitalize;" colspan="6">cart is empty</td></tr>';
      }
   ?>
   <tr class="table-bottom">
      <td colspan="4">Total Price :</td>
      <td><?php echo $grand_total; ?>$</td>
      <td><a href="user_cart.php?delete_all" onclick="return confirm('delete all products from cart?');" class="delete-btn <?php echo ($grand_total > 1)?'':'disabled'; ?>">Delete All</a></td>
   </tr>

   <tr class="table-bottom">
   <td colspan="6">
      <a href="checkout.php" class="option-btn">Go to Check out</a>
   </td>
   </tr>

</tbody>
</table>

</div>


    </center>

   </div>

</div>

</div>

</body>
</html>

