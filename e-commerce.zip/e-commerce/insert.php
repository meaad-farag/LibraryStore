<?php

include('config.php');

if(isset($_POST['upload'])){
    $NAME = $_POST['name'];
    $CATEGORY=$_POST['category'];
    $PRICE = $_POST['price'];
    $IMAGE = $_FILES['image'];
    $image_location = $_FILES['image']['tmp_name'];
    $image_name = $_FILES['image']['name'];
    $image_up = "images/".$image_name;
    $insert = "INSERT INTO products(name, category, price, image) VALUES ('$NAME','$CATEGORY', '$PRICE', '$image_up')";
    
    if (mysqli_query($conn, $insert)) {
        if (move_uploaded_file($image_location, "images/".$image_name)) {
            echo "<script>alert('The product has been uploaded successfully');</script>";
        } else {
            echo "<script>alert('Error! The product was not uploaded');</script>";
        }
    } else {
        echo "Error: " . $insert . "<br>" . mysqli_error($conn);
    }
    header('location: index.php');
}

?>

