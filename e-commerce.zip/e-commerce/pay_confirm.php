<?php
// Include the database connection file
include('config.php');
session_start();

$user_id = $_SESSION['user_id'];
if (!isset($user_id)) {
    header('location:login.php');
    exit();
}

// Get the order details from the form
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$address = $_POST['address'];
$card_name = $_POST['card_name'];
$card_number = $_POST['card_number'];

// Calculate the total price of the cart
$total_price = 0;
$cart_query = mysqli_query($conn, "SELECT * FROM `user_cart` WHERE user_id = '$user_id'") or die('query failed');
while ($fetch_cart = mysqli_fetch_assoc($cart_query)) {
    $total_price += (str_replace('$', '', $fetch_cart['price']) * $fetch_cart['quantity']);
}

// Insert the order details into the orders table
$query = "INSERT INTO orders (user_id, name, email, phone, address, card_name, card_number, total_price)
          VALUES ('$user_id', '$name', '$email', '$phone', '$address', '$card_name', '$card_number', '$total_price')";
$result = mysqli_query($conn, $query);

if ($result) {
    // Get the inserted order ID
    $order_id = mysqli_insert_id($conn);

    // Insert the product details into the order_items table
    $cart_query = mysqli_query($conn, "SELECT * FROM `user_cart` WHERE user_id = '$user_id'") or die('query failed');
    while ($fetch_cart = mysqli_fetch_assoc($cart_query)) {
        $product_id = $fetch_cart['id'];
        $product_name = $fetch_cart['name'];
        $price = str_replace('$', '', $fetch_cart['price']);
        $quantity = $fetch_cart['quantity'];

        $query = "INSERT INTO order_items (order_id, product_id, product_name, price, quantity)
                  VALUES ('$order_id', '$product_id', '$product_name', '$price', '$quantity')";
        mysqli_query($conn, $query);
    }

    // Clear the cart
    mysqli_query($conn, "DELETE FROM `user_cart` WHERE user_id = '$user_id'") or die('query failed');

    echo "Purchase completed successfully!";
} else {
    echo "Error occurred during the purchase.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid #dee2e6;
        }
        th, td {
            padding: 15px;
            text-align: center;
        }
        th {
            background-color: #f8f9fa;
        }

  
        .main{
    width: 40%;
    box-shadow: 1px 1px 10px silver;
    margin-top: 45px;
    padding: 10px;

        }
            
        h2{
            font-family: "Slabo 27px", serif;
        }
        input{
            margin-bottom: 10px;
            width: 50%;
            padding: 5px;
            font-family: "Slabo 27px", serif;
            font-size: 15px;
            font-weight: bold;

        }

        button{
            border:none;
            padding: 10px;
            width: 30%;
            font-weight: 15px;
            background-color: lightblue;
            cursor: pointer;
            font-family: "Slabo 27px", serif;
            margin-bottom: 15px;

        }

        label{
            padding: 10px;
            cursor: pointer;
            font-weight: bold;
            font-size: 18px;
            background-color: lightpink;
            font-family: "Slabo 27px", serif;
            
        }

        a{

            text-decoration: none;
            font-size: 20px;
         

        }
        nav {
                    background-color: #333;
            color: #fff;
            padding: 10px 20px;
        }
        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: space-between;
        }
        nav ul li {
            display: inline;
            padding: 0 10px;
        }
        nav ul li a {
            color: #fff;
            text-decoration: none;
        }
        nav ul li a:hover {
            text-decoration: underline;
        }

        nav ul{


            font-size:30px;
        }


    </style>
</head>
<body>
<nav>
        <ul>
           
            
            
            <li><a href="session_shop.php">Back to shopping</a></li>
            <li><a href="shop.php">Loge out</a></li>


            
        </ul>
    </nav>

</body>
</html>