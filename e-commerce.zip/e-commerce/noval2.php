<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>products</title>
    <style>
        h3{
            font-family: "Slabo 27px", serif;
            font-weight: bold;
        }

        h2{
            font-weight: bold;
            font-family: "Slabo 27px", serif;
        }

        .card{
            float: left;
            margin-top: 20px;
            margin-right: 10px;
            margin-left: 30px; 
            margin-bottom: 20px;
        }

        .card img{
            <center>
            width: 80%;
            height: 350px;
            <center>
        }

        main{
            width: 100%;

        }
        #a{
            margin-left: 70px;
            text-decoration: none;
            color: white;
        }
        img{
            box-shadow: 1px 1px 10px silver;
            margin-top: 45px;
        }

    </style>


    <link rel="stylesheet" href="index.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Slabo+27px&display=swap" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

</head>
<body>
    
    
    <nav class="navbar navbar-dark bg-dark">   

    <a id=a class="navbar-brand" href= "cart.php">My Cart</a>

    <select id="category" name="category" onchange="if (this.value !== '') window.location.href=this.value;">
    <option value="">Category</option>
    <option value="shop.php"><a href="shop.php">All Books</a></option>    
    <option value="noval2.php"> <a href="noval2.php">Novels</a> </option>
    <option value="children2.php"> <a href="children2.php">Children's Stories</a> </option>
    </select><br><br> 
    
    <a id=a class="navbar-brand" href= "login.php">Loge In</a>


   </nav>
    <center>
        <img src="logo2.png" alt="logo" width="1700px">
                <br><br>
        <h3>All Products</h3>

    </center>

    <?php
    include('config.php');
    $result = mysqli_query($conn, "SELECT * FROM products WHERE category = 'novels' ");
    while($row = mysqli_fetch_array($result)){
        ?>
            <center>
        
            <main>
                <div class='card' style='width: 15rem;'>
                    <img src= <?php echo $row['image']; ?> class='card-img-top' width="100">
                    <div class='card-body'>
                        <h5 class='card-title'><?php echo $row['name']; ?></h5>
                        <p class='card-text'><?php echo $row['price']; ?></p>
                        <p class='card-text'><?php echo $row['category']; ?></p>
                        <form method="post" class="box" action="">
                            <input type="number" min="1" name="product_quantity" value="1">
                            <input type="hidden" name="product_image" value="<?php echo $row['image']; ?>">
                            <input type="hidden" name="product_name" value="<?php echo $row['name']; ?>">
                            <input type="hidden" name="product_price" value="<?php echo $row['price']; ?>">
                            <input type="hidden" name="product_category" value="<?php echo $row['category']; ?>">
                            <input type="submit" value="Add to Cart" name="add_to_cart" class="btn btn-success">
                        </form>
                    </div>
                </div>
            </main>
            </center>
            
        <?php
        }
        ?>

    


    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>