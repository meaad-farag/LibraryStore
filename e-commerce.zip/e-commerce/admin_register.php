<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $role = 'admin'; 

    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    $sql = "INSERT INTO admin_users (username, email, password, role) VALUES ('$username', '$email', '$hashed_password', '$role')";
    if (mysqli_query($conn, $sql)) {
        echo "Registration successful.";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}
?>
<center>
<div class="main">
    <form method="post">
        <img src="logo.png" alt="logo" width="300px">
       <h3>Administrator registeration</h3>
    Admin Name: <input type="text" name="username" required><br>
    Admin Email: <input type="email" name="email" required><br>
    Admin Password: <input type="password" name="password" required><br>
    <input type="submit" value="Register">
    <p>loge in if you have account >> <a href="admin_login.php"> loge in </a></p>

</form>
</div>
</center>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
         .main{
    width: 40%;
    box-shadow: 1px 1px 10px silver;
    margin-top: 45px;
    padding: 10px;

        }
            
        h2{
            font-family: "Slabo 27px", serif;
        }
        input{
            margin-bottom: 10px;
            width: 50%;
            padding: 5px;
            font-family: "Slabo 27px", serif;
            font-size: 15px;
            font-weight: bold;

        }

        button{
            border:none;
            padding: 10px;
            width: 30%;
            font-weight: 15px;
            background-color: lightblue;
            cursor: pointer;
            font-family: "Slabo 27px", serif;
            margin-bottom: 15px;

        }

        label{
            padding: 10px;
            cursor: pointer;
            font-weight: bold;
            font-size: 10px;
            background-color: lightpink;
            font-family: "Slabo 27px", serif;
            
        }

        a{

            text-decoration: none;
            font-size:25px;
            
            font-weight: bold;


        }
        nav {
            background-color: #333;
            color: #fff;
            padding: 10px 20px;
        }
        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: space-between;
        }
        nav ul li {
            display: inline;
            padding: 0 10px;
        }
        nav ul li a {
            color: #fff;
            text-decoration: none;
        }
        nav ul li a:hover {
            text-decoration: underline;
        }
       

    </style>
</head>
<body>
    
</body>
</html>