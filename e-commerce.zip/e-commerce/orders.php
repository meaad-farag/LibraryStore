<?php
include('config.php');
session_start();

$user_id = $_SESSION['user_id'];
if (!isset($user_id)) {
    header('location:login.php');
    exit();
}

// Fetch orders for the current user
$orders_query = mysqli_query($conn, "SELECT * FROM `orders` WHERE user_id = '$user_id'") or die('query failed');

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Orders</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid #dee2e6;
        }
        th, td {
            padding: 15px;
            text-align: center;
        }
        th {
            background-color: #f8f9fa;
        }

  
        .main{
    width: 40%;
    box-shadow: 1px 1px 10px silver;
    margin-top: 45px;
    padding: 10px;

        }
            
        h2{
            font-family: "Slabo 27px", serif;
        }
        input{
            margin-bottom: 10px;
            width: 50%;
            padding: 5px;
            font-family: "Slabo 27px", serif;
            font-size: 15px;
            font-weight: bold;

        }

        button{
            border:none;
            padding: 10px;
            width: 30%;
            font-weight: 15px;
            background-color: lightblue;
            cursor: pointer;
            font-family: "Slabo 27px", serif;
            margin-bottom: 15px;

        }

        label{
            padding: 10px;
            cursor: pointer;
            font-weight: bold;
            font-size: 18px;
            background-color: lightpink;
            font-family: "Slabo 27px", serif;
            
        }

        a{

            text-decoration: none;
            font-size: 20px;
         

        }
        nav {
                    background-color: #333;
            color: #fff;
            padding: 10px 20px;
        }
        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: space-between;
        }
        nav ul li {
            display: inline;
            padding: 0 10px;
        }
        nav ul li a {
            color: #fff;
            text-decoration: none;
        }
        nav ul li a:hover {
            text-decoration: underline;
        }

        nav ul{


            font-size:30px;
        }


    </style>
</head>
<body>

<nav>
        <ul>
           
            
            <li>Current admin :<?php echo $_SESSION['username']; ?></li>
            <li><a href="index.php">Add products</a></li>
            <li><a href="shop.php">Go to store page</a></li>
            <li><a href="products.php">All products</a></li>
            <li><a href="admin_login.php">Loge out</a></li>


            
        </ul>
    </nav>

    <div class="container">
        <h1>My Orders</h1>
        <?php
        if (mysqli_num_rows($orders_query) > 0) {
            while ($order = mysqli_fetch_assoc($orders_query)) {
                $order_id = $order['id'];
                echo "<h2>Order ID: " . $order_id . "</h2>";
                echo "<p>Total Price: $" . $order['total_price'] . "</p>";
                echo "<p>Order Date: " . $order['order_date'] . "</p>";

                // Fetch order items for this order
                $items_query = mysqli_query($conn, "SELECT * FROM `order_items` WHERE order_id = '$order_id'") or die('query failed');
                
                if (mysqli_num_rows($items_query) > 0) {
                    echo "<table>";
                    echo "<thead>";
                    echo "<tr>";
                    echo "<th>Product ID</th>";
                    echo "<th>Product Name</th>";
                    echo "<th>Price</th>";
                    echo "<th>Quantity</th>";
                    echo "</tr>";
                    echo "</thead>";
                    echo "<tbody>";
                    while ($item = mysqli_fetch_assoc($items_query)) {
                        echo "<tr>";
                        echo "<td>" . $item['product_id'] . "</td>";
                        echo "<td>" . $item['product_name'] . "</td>";
                        echo "<td>$" . $item['price'] . "</td>";
                        echo "<td>" . $item['quantity'] . "</td>";
                        echo "</tr>";
                    }
                    echo "</tbody>";
                    echo "</table>";
                } else {
                    echo "<p>No items found for this order.</p>";
                }
                echo "<hr>";
            }
        } else {
            echo "<p>No orders found.</p>";
        }
        ?>
    </div>
</body>
</html>
