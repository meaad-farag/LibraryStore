<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>update</title>
    <link rel="stylesheet" type="text/css" href="index.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Slabo+27px&display=swap" rel="stylesheet">
</head>
<body>
    <?php
    include('config.php');
    $ID= $_GET['id'];
    $up = mysqli_query($conn, "select * from products where id =$ID");
    $data= mysqli_fetch_array($up);

    ?>


    <center>
      

        <div class="main">
        
            <form method="post" action="up.php" enctype="multipart/form-data">
                
                <h3>Edit products</h3>

                <label for="id"> pruduct id</label>
                <input type="text"  name="id" value='<?php echo $data['id']?>'><br>
                
                <label for="name">pruduct name</label>
                <input type="text"  name="name" value='<?php echo $data['name']?>'><br>
              
                <label for="price">product price :</label>
                <input type="text"  name="price" value='<?php echo $data['price']?>'><br>
                
                <label for="file">Update product image</label><br>
                <input type="file" id="file" name="image" style='display:none' required><br>
                <button type="submit" name="update">Edit product</button>
                <br><br>
                <a href="products.php">show all products</a>
            </form>


            </form>
        </div>
        <p>Developed by Meaad Farag, Software Engineer</p>

    </center>

</body>
</html>