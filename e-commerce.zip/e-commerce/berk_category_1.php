<?php

include 'config.php';
session_start();
$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
};

if(isset($_GET['logout'])){
   unset($user_id);
   session_destroy();
   header('location:shop.php');
};

if(isset($_POST['add_to_cart'])){

   $product_name = $_POST['product_name'];
   $product_price = $_POST['product_price'];
   $product_image = $_POST['product_image'];
   $product_quantity = $_POST['product_quantity'];

   $select_cart = mysqli_query($conn, "SELECT * FROM `user_cart` WHERE name = '$product_name' AND user_id = '$user_id'") or die('query failed');

   if(mysqli_num_rows($select_cart) > 0){
      $message[] = 'product is already in the cart';
   }else{
      mysqli_query($conn, "INSERT INTO `user_cart`(user_id, name, price, image, quantity) VALUES('$user_id', '$product_name', '$product_price', '$product_image', '$product_quantity')") or die('query failed');
      $message[] = 'product added to the cart ✔';
   }

};

if(isset($_POST['update_cart'])){
   $update_quantity = $_POST['cart_quantity'];
   $update_id = $_POST['cart_id'];
   mysqli_query($conn, "UPDATE `user_cart` SET quantity = '$update_quantity' WHERE id = '$update_id'") or die('query failed');
   $message[] = 'shopping cart quantity updated successfully!';
}

if(isset($_GET['remove'])){
   $remove_id = $_GET['remove'];
   mysqli_query($conn, "DELETE FROM `user_cart` WHERE id = '$remove_id'") or die('query failed');
   header('location:session_shop.php');
}
  
if(isset($_GET['delete_all'])){
   mysqli_query($conn, "DELETE FROM `user_cart` WHERE user_id = '$user_id'") or die('query failed');
   header('location:session_shop.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>berk_category_1</title>

   <style>
      
      .message {
           padding: 10px;
           background-color: #4caf50;
           color: white;
           margin-bottom: 15px;
           display: none;
       }
       
      h3{
            font-family: "Slabo 27px", serif;
            font-weight: bold;
        }

        h2{
            font-weight: bold;
            font-family: "Slabo 27px", serif;
        }

        .card{
            float: left;
            margin-top: 20px;
            margin-right: 10px;
            margin-left: 30px; 
            margin-bottom: 20px;
        }

        .card img{
            <center>
            width: 80%;
            height: 350px;
            <center>
        
        }

        main{
            <center>

            width: 100%;
            </center>

        }
        #a{
            margin-left: 10px;
            text-decoration: none;
            color: white;
        }
        img{
         
            box-shadow: 1px 1px 10px silver;
            margin-top: 45px;
         
        }

        .navbar {
            color: white;
            font-family: "Slabo 27px", serif;
            font-size: 25px;
            width: 100%;
        }

        .navbar a {
            color: white;
            font-family: "Slabo 27px", serif;
            font-size: 25px;
        }

        .navbar p {
            color: white;
            font-family: "Slabo 27px", serif;
            font-size: 25px;
        }

        .navbar span {
            color: white;
            font-family: "Slabo 27px", serif;
            font-size: 25px;
        }

        
        
         

    </style>


    <link rel="stylesheet" href="index.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Slabo+27px&display=swap" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

</head>
<body>
   
<?php
if(isset($message)){
   foreach($message as $message){
      echo '<div class="message" onclick="this.remove();">'.$message.'</div>';
   }
}


?>

<div class="container">
       <?php if(isset($message)): ?>
           <div class="message" id="messageBox"><?php echo $message; ?></div>
       <?php endif; ?>
       <!-- Your existing HTML code for the shop -->
   </div>

   <script>
       window.onload = function() {
           var messageBox = document.getElementById('messageBox');
           if (messageBox) {
               messageBox.style.display = 'block';
               setTimeout(function() {
                   messageBox.style.display = 'none';
               }, 4000); // Message will disappear after 4 seconds
           }
       }
   </script>

<div class="container">

<div class="user-profile">

   <?php
      $select_user = mysqli_query($conn, "SELECT * FROM `users` WHERE id = '$user_id'") or die('query failed');
      if(mysqli_num_rows($select_user) > 0){
         $fetch_user = mysqli_fetch_assoc($select_user);
      };
   ?>

<nav class="navbar navbar-dark bg-dark">   
    <a id="a" class="navbar-brand" href="user_cart.php">My Cart</a>
    <a> Welcome, <span><?php echo $fetch_user['name']; ?></span></a>

    <select id="category" name="category" onchange="handleCategoryChange(this)">
        <option value="">Category</option>
        <option value="session_shop.php">All Books</option>
        <option value="berk_category_1.php|berk_category_3.php">berk_category_1</option>
        <option value="berk_category_3.php">&nbsp;&nbsp;&nbsp;berk_category_3</option>
        <option value="berk_category_2.php|noval.php">berk_category_2</option>
        <option value="noval.php">&nbsp;&nbsp;&nbsp;Novels</option>
        <option value="children.php">Children's Stories</option>
    </select><br><br> 

    <a href="session_shop.php?logout=<?php echo $user_id; ?>" onclick="return confirm('Are you sure you want to log out?');" class="delete-btn">Log out</a>
</nav>

<script>
    function handleCategoryChange(select) {
        const selectedValue = select.value;
        if (selectedValue.includes('|')) {
            const [parentValue, childValue] = selectedValue.split('|');
            window.location.href = parentValue;
        } else {
            window.location.href = selectedValue;
        }
    }
</script>


    <center>
    <img src="logo2.png" alt="logo" style="width:100%; max-width: 1600px;">
                <br><br>

    </center>

</div>

<div class="products">
      <center>
         <h2 class="heading">berk_category_1</h2>
      </center>

   <div class="box-container">

   <?php
include('config.php');
$result = mysqli_query($conn, "SELECT * FROM products");

while($row = mysqli_fetch_array($result)){
?>
    <center>

    <main>
        <div class='card' style='width: 15rem;'>
            <img src= <?php echo $row['image']; ?> class='card-img-top' width="100">
            <div class='card-body'>
                <h5 class='card-title'><?php echo $row['name']; ?></h5>
                <p class='card-text'><?php echo $row['price']; ?></p>
                <p class='card-text'><?php echo $row['category']; ?></p>
                <form method="post" class="box" action="">
                    <input type="number" min="1" name="product_quantity" value="1">
                    <input type="hidden" name="product_image" value="<?php echo $row['image']; ?>">
                    <input type="hidden" name="product_name" value="<?php echo $row['name']; ?>">
                    <input type="hidden" name="product_price" value="<?php echo $row['price']; ?>">
                    <input type="hidden" name="product_category" value="<?php echo $row['category']; ?>">
                    <input type="submit" value="Add to Cart" name="add_to_cart" class="btn btn-success">
                </form>
            </div>
        </div>
    </main>
    </center>
    
<?php
}
?>


   </div>

</div>

</div>

</body>
</html>