<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="index.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Slabo+27px&display=swap" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Cart</title>
    <style>
        h3 {
            font-family: "Slabo 27px", serif;
            font-weight: bold;
        }

        main {
            width:60%;
            margin-top: 30px;
        }

        table {
            box-shadow: 1px 1px 10px silver;
        }

        thead {
            background-color: lightpink;
            text-align: center;
        }

        tbody {
            text-align: center;
        }
    </style>
</head>
<body>

    <nav class="navbar navbar-dark bg-dark">
        <a id="a" class="navbar-brand" href="shop.php">Back to shopping</a>
        <a id="a" class="navbar-brand" href="login.php">Loge In</a>

    </nav>
  
    <center>

        <h3>Cart Products</h3>
    </center>
    <?php
    include('config.php');

    if (isset($_POST['update_quantity'])) {
        $cart_id = $_POST['cart_id'];
        $new_quantity = $_POST['quantity'];
        mysqli_query($conn, "UPDATE cart SET quantity = '$new_quantity' WHERE id = '$cart_id'") or die('Query failed');
        echo "<script>alert('Quantity updated successfully');</script>";
    }

    $result = mysqli_query($conn, "SELECT * FROM cart");
    while ($row = mysqli_fetch_array($result)) {
        echo "
        <center>
        <main>
            <table class='table'>
                <thead>
                    <tr>
                        <th scope='col'>Product Name</th>
                        <th scope='col'>Product Price</th>
                        <th scope='col'>Quantity</th>
                        <th scope='col'>Update Quantity</th>
                        <th scope='col'>Delete Product</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>{$row['name']}</td>
                        <td>{$row['price']}</td>
                        <td>
                            <form action='' method='post'>
                                <input type='hidden' name='cart_id' value='{$row['id']}'>
                                <input type='number' name='quantity' value='{$row['quantity']}' min='1'>
                        </td>
                        <td>
                                <input type='submit' name='update_quantity' value='Update' class='btn btn-success'>
                            </form>
                        </td>
                        <td><a href='del_cart.php?id={$row['id']}' class='btn btn-danger'>Delete</a></td>
                    </tr>

                    
                
                </tbody>

                
            </table>

        </main>
        
        </center>";
        
    }

  
  ?>

        <center>
        <tr class='table-bottom'>
        <td colspan='6'>
        <a href='session_shop.php' class='option-btn'> Login to Check out</a>
        </td>
        </tr>
        </center>

    

        
        

    

    
</body>
</html>
