<?php
session_start();
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM admin_users WHERE username='$username'";
    $result = mysqli_query($conn, $sql);
    $user = mysqli_fetch_assoc($result);

    if (password_verify($password, $user['password'])) {
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        header('Location: index.php');
    } else {
        echo "Invalid username or password.";
    }
}
?>
<center>
<div class="main">
    <form method="post">
        <img src="logo.png" alt="logo" width="300px">
       <h3>Administrator login</h3>
       Admin Name: <input type="text" name="username" required><br>
       Admin Password: <input type="password" name="password" required><br>
        <input type="submit" value="Login">
        <p>create account if you do not have >>  <a href="admin_register.php"> new account </a></p>
    </form>
</div>
</center>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>
        .main{
    width: 40%;
    box-shadow: 1px 1px 10px silver;
    margin-top: 45px;
    padding: 10px;

        }
            
        h2{
            font-family: "Slabo 27px", serif;
        }
        input{
            margin-bottom: 10px;
            width: 50%;
            padding: 5px;
            font-family: "Slabo 27px", serif;
            font-size: 15px;
            font-weight: bold;

        }

        button{
            border:none;
            padding: 10px;
            width: 30%;
            font-weight: 15px;
            background-color: lightblue;
            cursor: pointer;
            font-family: "Slabo 27px", serif;
            margin-bottom: 15px;

        }

        label{
            padding: 10px;
            cursor: pointer;
            font-weight: bold;
            font-size: 10px;
            background-color: lightpink;
            font-family: "Slabo 27px", serif;
            
        }

        a{

            text-decoration: none;
            font-size:25px;
            
            font-weight: bold;


        }
        nav {
            background-color: #333;
            color: #fff;
            padding: 10px 20px;
        }
        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: space-between;
        }
        nav ul li {
            display: inline;
            padding: 0 10px;
        }
        nav ul li a {
            color: #fff;
            text-decoration: none;
        }
        nav ul li a:hover {
            text-decoration: underline;
        }
       

    </style>
</head>
<body>
    
</body>
</html>