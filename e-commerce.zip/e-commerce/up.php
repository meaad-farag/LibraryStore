<?php

include('config.php');

if(isset($_POST['update'])){
    $ID = $_POST['id'];
    $NAME = $_POST['name'];
    $PRICE = $_POST['price'];
    $IMAGE = $_FILES['image'];
    $image_location = $_FILES['image']['tmp_name'];
    $image_name = $_FILES['image']['name'];
    $image_up = "images/".$image_name;
    $update = "UPDATE products SET name ='$NAME', price='$PRICE', image='$image_up' WHERE id=$ID " ;  
    if (mysqli_query($conn, $update)) {
        if (move_uploaded_file($image_location, "images/".$image_name)) {
            echo "<script>alert('The product has been updated successfully');</script>";
        } else {
            echo "<script>alert('Error! The product was not updated');</script>";
        }
    } else {
        echo "Error: " . $insert . "<br>" . mysqli_error($conn);
    }
    header('location: products.php');
}

?>
