
<?php


phpinfo();