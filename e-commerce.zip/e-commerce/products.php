<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {
    header('Location: admin_login.php');
    exit();
}?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>products</title>
    <style>
        h3{
            font-family: "Slabo 27px", serif;
            font-weight: bold;
        }

        h2{
            font-weight: bold;
            font-family: "Slabo 27px", serif;
        }

        .card{
            float: left;
            margin-top: 20px;
            margin-right: 10px;
            margin-left: 30px; 
            margin-bottom: 20px;
        }

        .card img{
            <center>
            width: 80%;
            height: 350px;
            <center>
        }

        main{
            width: 100%;

        }
        nav {
            background-color: #333;
            color: #fff;
            padding: 10px 20px;
        }
        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: space-between;
        }
        nav ul li {
            display: inline;
            padding: 0 10px;
        }
        nav ul li a {
            color: #fff;
            text-decoration: none;
        }
        nav ul li a:hover {
            text-decoration: underline;
        }
        
         nav ul{


        font-size:30px;
        }

    

    </style>


    <link rel="stylesheet" href="index.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Slabo+27px&display=swap" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

</head>
<body>

<nav>
        <ul>
           
            
            <li>Current admin :<?php echo $_SESSION['username']; ?></li>
            <li><a href="orders.php">Orders</a></li>
            <li><a href="shop.php">Go to store page</a></li>
            <li><a href="index.php">Add products</a></li>
            <li><a href="admin_login.php">Loge out</a></li>


            
        </ul>
    </nav>

    <br><br>
    <center>
        <h3>All Products</h3>

    </center>

    <?php
    include('config.php');
    $result = mysqli_query($conn, "SELECT * FROM products");
    while($row = mysqli_fetch_array($result)){
        echo "
        <center>
        <main>
            <div class='card' style='width: 15rem;'>
                <img src='$row[image]' class='card-img-top'>
                <div class='card-body'>
                    <h5 class='card-title'>$row[name]</h5>
                    <p class='card-text'>$row[price]</p>
                    <p class='card-text'>$row[category]</p>
                    <a href='update.php? id=$row[id]' class='btn btn-primary'>Edit product</a>
                    <a href='delete.php? id=$row[id]' class='btn btn-danger'>Delete product</a>
                    
                </div>
             </div>

        </main>
        <center>
        
        ";

    }
    ?>

    


    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>